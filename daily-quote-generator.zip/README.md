# مولد الاقتباسات اليومية

تطبيق ويب عصري (PWA) يعرض اقتباسًا ملهمًا جديدًا كل يوم — حكم من ثقافات العالم واقتباسات إسلامية (آيات قرآنية وأحاديث صحيحة وحكم إسلامية) — مبني بـ **Next.js + TypeScript + Tailwind CSS + Framer Motion**.

> **وضع التشغيل: تصدير ثابت (Static Export)** — `npm run build` ينتج مجلد `out/` من ملفات HTML/CSS/JS جاهزة تُرفع على أي استضافة ثابتة بدون خادم.

## المميزات

- **نظام اقتباس اليوم**: اقتباس ثابت ومحدد لكل يوم، مع إمكانية تغييره يدويًا في أي وقت
- **تصنيفان**: «حكم عالمية» من ثقافات متعددة، و«اقتباسات إسلامية» (آيات، أحاديث، حكم) فقط
- **نسخ ومشاركة**: نسخ الاقتباس إلى الحافظة أو مشاركته عبر Web Share API
- **حفظ آخر اقتباس**: يُحفظ تلقائيًا في `localStorage` ويعود عند إعادة الفتح في نفس اليوم
- **تذكير يومي**: إشعارات ويب (Web Notifications) عند وقت يحدده المستخدم
- **PWA قابلة للتثبيت**: مثبّتة على الهاتف/سطح المكتب مع Manifest وService Worker وأيقونات
- **تصميم 2026**: تأثيرات 3D خفيفة (إمالة البطاقة مع Pointer)، خلفيات أورورا متحركة تتغير تلقائيًا، نجوم متلألئة، Glassmorphism، وحركات سلسة بـ Framer Motion
- **بدون قاعدة بيانات**: كل الاقتباسات في `lib/quotes.ts`
- **متجاوب بالكامل** مع الهاتف والكمبيوتر

تصميم وتطوير: **عبدالملك القطامي**

## المتطلبات

- Node.js 18.18 أو أحدث
- npm

## التشغيل محليًا

```bash
npm install
npm run dev
```

ثم افتح [http://localhost:3000](http://localhost:3000).

## البناء والتصدير الثابت

```bash
npm run build
```

ينتج مجلد `out/` جاهزًا للرفع (مجلد التصدير مُعرّف في `next.config.ts` عبر `output: "export"`).

لمعاينة ناتج التصدير محليًا:

```bash
npm run start
# أو
npm run preview
```

## أوامر مفيدة

| الأمر | الوصف |
| --- | --- |
| `npm run dev` | تشغيل خادم التطوير |
| `npm run build` | بناء مجلد التصدير `out/` |
| `npm run start` / `preview` | معاينة مجلد `out/` محليًا على المنفذ 3000 |
| `npm run lint` | فحص الكود بـ ESLint |
| `npm run deploy` | نشر نسخة الإنتاج على Vercel |
| `npm run deploy:preview` | نشر نسخة معاينة على Vercel |
| `npm run deploy:prepare` | ربط المشروع بحساب Vercel |

## النشر على Vercel

`vercel.json` مُعدّ مسبقًا (Framework: Next.js، `outputDirectory: "out"`):

1. ارفع الكود إلى مستودع GitHub
2. في [vercel.com](https://vercel.com) اضغط **Add New → Project** واستورد المستودع
3. اضغط **Deploy**

أو من سطر الأوامر بعد `vercel login`:

```bash
npm run deploy:prepare   # ربط المشروع بحساب Vercel (مرة واحدة)
npm run deploy           # نشر نسخة الإنتاج
```

> للنشر التلقائي من GitHub، المستودع يتضمن `.github/workflows/deploy-vercel.yml` —
> أضف أسرار `VERCEL_TOKEN` و`VERCEL_ORG_ID` و`VERCEL_PROJECT_ID` في
> GitHub → Settings → Secrets and variables → Actions.

## النشر على أي استضافة ثابتة (Netlify، GitHub Pages، Cloudflare Pages، Surge)

بما أن المشروع يُصدَّر لمجلد ثابت `out/`، يكفي رفع مجلد `out/`:

```bash
npm install
npm run build
# ثم ارفع محتوى مجلد out/ إلى استضافتك
```

| المنصة | خطوات سريعة |
| --- | --- |
| **Netlify** | سحب وإفلات مجلد `out/` على app.netlify.com/drop — أو Build command: `npm run build` و Publish directory: `out` |
| **GitHub Pages** | عدّل `next.config.ts` وأضف `trailingSlash: true` وأعد البناء، ثم ارفع محتوى `out/` إلى فرع `gh-pages` |
| **Cloudflare Pages** | Build command: `npm run build`، Output directory: `out` |
| **Surge** | `npm run build && npx surge out` |

## البنية

```
app/                  الصفحة والتخطيط والأنماط
  layout.tsx          إعدادات Metadata + Viewport + خط Cairo + RTL
  page.tsx            الصفحة الرئيسية
  manifest.ts         PWA Manifest (تصدير ثابت)
  globals.css         Tailwind + نظام التصميم والأنيميشن
  icon.svg            أيقونة الموقع
components/
  QuoteGenerator.tsx  المنسّق الرئيسي: الخلفية، التصنيفات، الحفظ، الإشعارات
  QuoteCard.tsx       بطاقة الاقتباس والأزرار
  TiltCard.tsx        تأثير الإمالة ثلاثي الأبعاد
  ReminderPanel.tsx   لوحة التذكير اليومي والإشعارات
lib/
  quotes.ts           بيانات الاقتباسات (عالمية + إسلامية)
  daily.ts            منطق اقتباس اليوم والتواريخ
public/
  sw.js               Service Worker (PWA)
  icons/              أيقونات PWA
next.config.ts        إعدادات التصدير الثابت
vercel.json           إعدادات النشر على Vercel
.github/workflows/    نشر تلقائي عبر GitHub Actions
```

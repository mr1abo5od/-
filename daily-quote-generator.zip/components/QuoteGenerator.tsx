"use client";

import { AnimatePresence, motion, useMotionValue, useSpring, useTransform } from "framer-motion";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import QuoteCard from "@/components/QuoteCard";
import ReminderPanel, { triggerReminderNotification, type ReminderState } from "@/components/ReminderPanel";
import TiltCard from "@/components/TiltCard";
import { dateKey, getDayIndex, getQuoteOfDay } from "@/lib/daily";
import { getQuotesByCategory, findQuoteById, type Quote, type QuoteCategory } from "@/lib/quotes";

const QUOTE_STORAGE_KEY = "dq:quote";
const REMINDER_STORAGE_KEY = "dq:reminder";
const REMINDER_SHOWN_KEY = "dq:reminder-shown";
const SCENE_INTERVAL_MS = 10000;

type StoredQuote = {
  date: string;
  quoteId: string;
  category: QuoteCategory;
};

type SceneBlob = {
  color: string;
  top?: string;
  left?: string;
  bottom?: string;
  right?: string;
  size: number;
  animation: string;
  duration: number;
  delay: string;
};

type Scene = {
  background: string;
  blobs: SceneBlob[];
};

const SCENES: Scene[] = [
  {
    background: "radial-gradient(at 20% 20%, #1e1b4b 0%, #0b0f1a 48%, #0b0f1a 100%)",
    blobs: [
      { color: "#4f46e5", top: "-10%", left: "-10%", size: 480, animation: "aurora-a", duration: 14, delay: "0s" },
      { color: "#a855f7", top: "40%", left: "60%", size: 420, animation: "aurora-b", duration: 17, delay: "-4s" },
      { color: "#0ea5e9", bottom: "-15%", left: "20%", size: 460, animation: "aurora-c", duration: 15, delay: "-8s" },
    ],
  },
  {
    background: "radial-gradient(at 80% 10%, #3b0764 0%, #0b0f1a 52%, #0b0f1a 100%)",
    blobs: [
      { color: "#ec4899", top: "-5%", left: "55%", size: 460, animation: "aurora-b", duration: 15, delay: "0s" },
      { color: "#8b5cf6", top: "45%", left: "-10%", size: 430, animation: "aurora-a", duration: 18, delay: "-6s" },
      { color: "#f43f5e", bottom: "-10%", left: "50%", size: 400, animation: "aurora-c", duration: 13, delay: "-3s" },
    ],
  },
  {
    background: "radial-gradient(at 15% 85%, #052e2b 0%, #0b0f1a 50%, #0b0f1a 100%)",
    blobs: [
      { color: "#10b981", top: "55%", left: "-10%", size: 440, animation: "aurora-a", duration: 16, delay: "0s" },
      { color: "#22d3ee", top: "-15%", left: "40%", size: 420, animation: "aurora-c", duration: 14, delay: "-5s" },
      { color: "#f59e0b", bottom: "-12%", left: "60%", size: 430, animation: "aurora-b", duration: 17, delay: "-9s" },
    ],
  },
  {
    background: "radial-gradient(at 75% 75%, #2e1065 0%, #0b0f1a 55%, #0b0f1a 100%)",
    blobs: [
      { color: "#6366f1", top: "-10%", left: "30%", size: 450, animation: "aurora-c", duration: 13, delay: "0s" },
      { color: "#d946ef", top: "50%", left: "55%", size: 410, animation: "aurora-a", duration: 18, delay: "-7s" },
      { color: "#38bdf8", bottom: "-15%", left: "-5%", size: 470, animation: "aurora-b", duration: 16, delay: "-4s" },
    ],
  },
];

type BeforeInstallPromptEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
};

function generateStars(count: number) {
  return Array.from({ length: count }, (_, index) => ({
    id: index,
    top: `${Math.random() * 100}%`,
    left: `${Math.random() * 100}%`,
    size: Math.random() * 2 + 1,
    duration: 3 + Math.random() * 4,
    delay: `${(Math.random() * 5).toFixed(2)}s`,
  }));
}

const STARS = generateStars(70);

function loadStoredQuote(): StoredQuote | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(QUOTE_STORAGE_KEY);
    return raw ? (JSON.parse(raw) as StoredQuote) : null;
  } catch {
    return null;
  }
}

function saveStoredQuote(value: StoredQuote) {
  try {
    localStorage.setItem(QUOTE_STORAGE_KEY, JSON.stringify(value));
  } catch {
    /* storage unavailable */
  }
}

function loadReminder(): ReminderState {
  const defaults: ReminderState = { enabled: false, time: "09:00", granted: false };
  if (typeof window === "undefined") return defaults;
  try {
    const raw = localStorage.getItem(REMINDER_STORAGE_KEY);
    return raw ? { ...defaults, ...(JSON.parse(raw) as Partial<ReminderState>) } : defaults;
  } catch {
    return defaults;
  }
}

export default function QuoteGenerator() {
  const [category, setCategory] = useState<QuoteCategory>("world");
  const [quote, setQuote] = useState<Quote>(() => {
    const stored = loadStoredQuote();
    const today = dateKey();
    if (stored && stored.date === today) {
      const restored = findQuoteById(stored.quoteId);
      if (restored) return restored;
    }
    return getQuoteOfDay(getQuotesByCategory("world"));
  });
  const [sceneIndex, setSceneIndex] = useState(() => Math.floor(Math.random() * SCENES.length));
  const [scenePaused, setScenePaused] = useState(false);
  const [copied, setCopied] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const [reminder, setReminder] = useState<ReminderState>(loadReminder);
  const [installPrompt, setInstallPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [appInstalled, setAppInstalled] = useState(false);

  const list = useMemo(() => getQuotesByCategory(category), [category]);
  const quoteOfToday = useMemo(() => getQuoteOfDay(list), [list]);
  const isDaily = quote.id === quoteOfToday.id;

  const px = useMotionValue(0);
  const py = useMotionValue(0);
  const bgX = useSpring(useTransform(px, [-1, 1], [-14, 14]), { stiffness: 120, damping: 20 });
  const bgY = useSpring(useTransform(py, [-1, 1], [-14, 14]), { stiffness: 120, damping: 20 });

  const shownToastRef = useRef<string | null>(null);

  const showToast = useCallback((message: string) => {
    if (shownToastRef.current === message) return;
    shownToastRef.current = message;
    setToast(message);
    window.setTimeout(() => {
      setToast(null);
      shownToastRef.current = null;
    }, 2200);
  }, []);

  const pickRandom = useCallback(() => {
    if (list.length <= 1) return;
    let next = quote;
    while (next.id === quote.id) {
      next = list[Math.floor(Math.random() * list.length)];
    }
    setQuote(next);
  }, [list, quote]);

  function selectCategory(next: QuoteCategory) {
    setCategory(next);
    setQuote(getQuoteOfDay(getQuotesByCategory(next)));
  }

  useEffect(() => {
    const today = dateKey();
    saveStoredQuote({ date: today, quoteId: quote.id, category });
  }, [quote, category]);

  useEffect(() => {
    if (scenePaused) return;
    const interval = setInterval(() => {
      setSceneIndex((index) => (index + 1) % SCENES.length);
    }, SCENE_INTERVAL_MS);
    return () => clearInterval(interval);
  }, [scenePaused]);

  useEffect(() => {
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.register("/sw.js").catch(() => {});
    }
    const onBeforeInstall = (event: Event) => {
      event.preventDefault();
      setInstallPrompt(event as BeforeInstallPromptEvent);
    };
    const onInstalled = () => {
      setInstallPrompt(null);
      setAppInstalled(true);
    };
    window.addEventListener("beforeinstallprompt", onBeforeInstall);
    window.addEventListener("appinstalled", onInstalled);
    return () => {
      window.removeEventListener("beforeinstallprompt", onBeforeInstall);
      window.removeEventListener("appinstalled", onInstalled);
    };
  }, []);

  useEffect(() => {
    if (!reminder.enabled || !reminder.granted) return;
    const checkReminder = async () => {
      if (typeof window === "undefined" || !("Notification" in window) || Notification.permission !== "granted") return;
      const now = new Date();
      const [hours, minutes] = reminder.time.split(":").map(Number);
      const reached = now.getHours() > hours || (now.getHours() === hours && now.getMinutes() >= minutes);
      if (!reached) return;
      const today = dateKey();
      if (localStorage.getItem(REMINDER_SHOWN_KEY) === today) return;
      localStorage.setItem(REMINDER_SHOWN_KEY, today);
      await triggerReminderNotification("اقتباس اليوم بانتظارك", `reminder-${today}`);
    };
    checkReminder();
    const interval = setInterval(checkReminder, 30000);
    return () => clearInterval(interval);
  }, [reminder.enabled, reminder.granted, reminder.time]);

  useEffect(() => {
    try {
      localStorage.setItem(REMINDER_STORAGE_KEY, JSON.stringify(reminder));
    } catch {
      /* storage unavailable */
    }
  }, [reminder]);

  const copyQuote = useCallback(async () => {
    const text = `${quote.text}\n— ${quote.author}${quote.source ? ` (${quote.source})` : ""}`;
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      const textarea = document.createElement("textarea");
      textarea.value = text;
      textarea.style.position = "fixed";
      textarea.style.opacity = "0";
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand("copy");
      document.body.removeChild(textarea);
    }
    setCopied(true);
    showToast("تم نسخ الاقتباس إلى الحافظة");
    window.setTimeout(() => setCopied(false), 1600);
  }, [quote, showToast]);

  const shareQuote = useCallback(async () => {
    const text = `${quote.text}\n— ${quote.author}${quote.source ? ` (${quote.source})` : ""}\n\nمن تطبيق مولد الاقتباسات اليومية`;
    const shareData = { title: "مولد الاقتباسات اليومية", text };
    try {
      if (navigator.share) {
        await navigator.share(shareData);
      } else {
        await navigator.clipboard.writeText(text);
        showToast("تم نسخ الاقتباس للمشاركة");
      }
    } catch {
      /* user cancelled share */
    }
  }, [quote, showToast]);

  const installApp = useCallback(async () => {
    if (!installPrompt) return;
    await installPrompt.prompt();
    const choice = await installPrompt.userChoice;
    if (choice.outcome === "accepted") {
      setInstallPrompt(null);
      setAppInstalled(true);
      showToast("تم تثبيت التطبيق");
    }
  }, [installPrompt, showToast]);

  function onPointerMove(event: React.PointerEvent<HTMLDivElement>) {
    px.set((event.clientX / window.innerWidth) * 2 - 1);
    py.set((event.clientY / window.innerHeight) * 2 - 1);
  }

  const stars = STARS;

  return (
    <div
      className="relative min-h-screen w-full overflow-hidden text-white"
      onPointerMove={onPointerMove}
    >
      <div className="absolute inset-0">
        {SCENES.map((scene, index) => (
          <div
            key={index}
            aria-hidden
            className={`absolute inset-0 transition-opacity duration-[1800ms] ease-in-out ${
              index === sceneIndex ? "opacity-100" : "opacity-0"
            }`}
            style={{ background: scene.background }}
          >
            <motion.div
              className="absolute inset-0"
              style={{ x: bgX, y: bgY }}
            >
              {scene.blobs.map((blob, blobIndex) => (
                <div
                  key={blobIndex}
                  className="aurora-blob"
                  style={{
                    background: `radial-gradient(circle, ${blob.color}66 0%, transparent 70%)`,
                    top: blob.top,
                    left: blob.left,
                    bottom: blob.bottom,
                    right: blob.right,
                    width: blob.size,
                    height: blob.size,
                    animation: `${blob.animation} ${blob.duration}s ease-in-out ${blob.delay} infinite`,
                  }}
                />
              ))}
            </motion.div>
          </div>
        ))}

        <div aria-hidden className="absolute inset-0">
          {stars.map((star) => (
            <span
              key={star.id}
              className="absolute rounded-full bg-white"
              style={{
                top: star.top,
                left: star.left,
                width: star.size,
                height: star.size,
                animation: `twinkle ${star.duration}s ease-in-out ${star.delay} infinite`,
              }}
            />
          ))}
        </div>
      </div>

      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_55%,rgba(0,0,0,0.45)_100%)]" />

      <div className="relative z-10 mx-auto flex min-h-screen max-w-3xl flex-col items-center px-4 pb-10 pt-12 sm:pt-16">
        <motion.header
          initial={{ opacity: 0, y: -16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
          className="mb-8 text-center"
        >
          <p className="mb-3 text-xs font-semibold uppercase tracking-[0.35em] text-white/55 sm:text-sm">
            مولد الاقتباسات اليومية
          </p>
          <h1 className="text-4xl font-black leading-tight sm:text-6xl">
            <span className="text-gradient">اقتباس</span> يُلهم يومك
          </h1>
          <p className="mt-4 text-sm text-white/60 sm:text-base">
            حكم من ثقافات العالم واقتباسات إسلامية، يصل إليك كل يوم
          </p>
        </motion.header>

        <motion.nav
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="glass mb-6 flex w-full max-w-sm gap-1 rounded-2xl p-1.5"
          aria-label="تصنيف الاقتباسات"
        >
          {(
            [
              { key: "world", label: "حكم عالمية" },
              { key: "islamic", label: "اقتباسات إسلامية" },
            ] as { key: QuoteCategory; label: string }[]
          ).map((tab) => (
            <button
              key={tab.key}
              type="button"
              onClick={() => selectCategory(tab.key)}
              className={`relative flex-1 rounded-xl px-4 py-2.5 text-sm font-bold transition-colors ${
                category === tab.key ? "text-white" : "text-white/55 hover:text-white/85"
              }`}
            >
              {category === tab.key && (
                <motion.span
                  layoutId="tab-pill"
                  className="absolute inset-0 rounded-xl bg-gradient-to-r from-indigo-500 via-purple-500 to-fuchsia-500 shadow-lg shadow-fuchsia-500/25"
                  transition={{ type: "spring", stiffness: 380, damping: 30 }}
                />
              )}
              <span className="relative z-10">{tab.label}</span>
            </button>
          ))}
        </motion.nav>

        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="w-full"
          style={{ perspective: 1200 }}
        >
          <TiltCard className="relative w-full rounded-[2rem]">
            <QuoteCard
              quote={quote}
              isDaily={isDaily}
              copied={copied}
              onNew={pickRandom}
              onCopy={copyQuote}
              onShare={shareQuote}
            />
          </TiltCard>

          <div className="mt-4 flex items-center gap-3 px-1">
            <div className="h-1 flex-1 overflow-hidden rounded-full bg-white/10">
              {!scenePaused && (
                <div
                  key={sceneIndex}
                  className="h-full origin-right rounded-full bg-gradient-to-l from-indigo-400 to-fuchsia-400"
                  style={{ animation: `progress ${SCENE_INTERVAL_MS}ms linear forwards` }}
                />
              )}
            </div>
            <button
              type="button"
              onClick={() => setScenePaused((value) => !value)}
              className="flex items-center gap-1.5 rounded-full border border-white/15 bg-white/5 px-3 py-1.5 text-xs font-semibold text-white/75 transition-colors hover:bg-white/10"
            >
              {scenePaused ? (
                <svg className="h-3.5 w-3.5" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M8 5v14l11-7z" />
                </svg>
              ) : (
                <svg className="h-3.5 w-3.5" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M6 5h4v14H6zM14 5h4v14h-4z" />
                </svg>
              )}
              {scenePaused ? "استئناف الخلفية" : "إيقاف الخلفية"}
            </button>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.35 }}
          className="mt-6 w-full space-y-4"
        >
          <ReminderPanel state={reminder} onChange={setReminder} />

          {installPrompt && !appInstalled && (
            <motion.button
              type="button"
              onClick={installApp}
              whileHover={{ y: -1 }}
              whileTap={{ scale: 0.98 }}
              className="glass flex w-full items-center justify-center gap-2 rounded-2xl px-5 py-3.5 text-sm font-bold text-white transition-colors hover:bg-white/10"
            >
              <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                <path d="m7 10 5 5 5-5" />
                <path d="M12 15V3" />
              </svg>
              تثبيت التطبيق على جهازك
            </motion.button>
          )}
          {appInstalled && (
            <p className="text-center text-xs text-emerald-300/90">
              تم تثبيت التطبيق بنجاح
            </p>
          )}
        </motion.div>

        <footer className="mt-10 flex flex-col items-center gap-1 text-center">
          <p className="text-xs text-white/45">
            {getQuotesByCategory(category).length} اقتباس — يوم {getDayIndex()} من السنة
          </p>
          <p className="text-xs font-semibold text-white/60">
            تصميم وتطوير <span className="text-gradient font-bold">عبدالملك القطامي</span>
          </p>
        </footer>
      </div>

      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ opacity: 0, y: 18, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 12, scale: 0.95 }}
            transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
            className="glass fixed bottom-8 left-1/2 z-20 rounded-full px-5 py-2.5 text-sm font-bold text-white shadow-2xl"
          >
            {toast}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
